import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/filters.dart';
import '../models/property.dart';
import '../theme/app_theme.dart';
import '../widgets/property_card.dart';
import 'filter_screen.dart';
import 'property_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  PropertyFilters filters = PropertyFilters();
  final TextEditingController _searchController = TextEditingController();

  List<Property> get _filtered =>
      mockProperties.where((p) => filters.matches(p)).toList();

  void _openFilters() async {
    final result = await Navigator.push<PropertyFilters>(
      context,
      MaterialPageRoute(builder: (_) => FilterScreen(initial: filters.copy())),
    );
    if (result != null) {
      setState(() => filters = result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final results = _filtered;

    return Scaffold(
      appBar: AppBar(
        title: const Text('RoomFinder'),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune),
            onPressed: _openFilters,
            tooltip: 'Filters',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                hintText: 'Search by city, neighborhood...',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                setState(() => filters.query = value);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(
                  '${results.length} results',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: results.isEmpty
                ? const _EmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 16),
                    itemCount: results.length,
                    itemBuilder: (context, index) {
                      final property = results[index];
                      return PropertyCard(
                        property: property,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  PropertyDetailScreen(property: property),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.search_off, size: 56, color: AppTheme.textLight),
          const SizedBox(height: 12),
          Text('No properties match your search',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text('Try adjusting your filters',
              style: TextStyle(color: AppTheme.textLight)),
        ],
      ),
    );
  }
}
