import 'package:flutter/material.dart';
import '../models/filters.dart';
import '../models/property.dart';

class FilterScreen extends StatefulWidget {
  final PropertyFilters initial;
  const FilterScreen({super.key, required this.initial});

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  late PropertyFilters filters;

  @override
  void initState() {
    super.initState();
    filters = widget.initial.copy();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Filters'),
        actions: [
          TextButton(
            onPressed: () {
              setState(() => filters = PropertyFilters());
            },
            child: const Text('Reset'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Price range', style: Theme.of(context).textTheme.titleMedium),
          RangeSlider(
            values: RangeValues(filters.minPrice, filters.maxPrice),
            min: 0,
            max: 2000,
            divisions: 40,
            labels: RangeLabels(
              '€${filters.minPrice.round()}',
              '€${filters.maxPrice.round()}',
            ),
            onChanged: (values) {
              setState(() {
                filters.minPrice = values.start;
                filters.maxPrice = values.end;
              });
            },
          ),
          const SizedBox(height: 12),
          Text('Property type', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: PropertyType.values.map((type) {
              final selected = filters.types.contains(type);
              return FilterChip(
                label: Text(_typeLabel(type)),
                selected: selected,
                onSelected: (value) {
                  setState(() {
                    if (value) {
                      filters.types.add(type);
                    } else {
                      filters.types.remove(type);
                    }
                  });
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          Text('Minimum bedrooms',
              style: Theme.of(context).textTheme.titleMedium),
          Slider(
            value: filters.minBedrooms.toDouble(),
            min: 0,
            max: 5,
            divisions: 5,
            label: '${filters.minBedrooms}',
            onChanged: (value) {
              setState(() => filters.minBedrooms = value.round());
            },
          ),
          const SizedBox(height: 12),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Furnished only'),
            value: filters.furnishedOnly,
            onChanged: (value) => setState(() => filters.furnishedOnly = value),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Pets allowed'),
            value: filters.petsAllowedOnly,
            onChanged: (value) =>
                setState(() => filters.petsAllowedOnly = value),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => Navigator.pop(context, filters),
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('Apply filters'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _typeLabel(PropertyType type) {
    switch (type) {
      case PropertyType.apartment:
        return 'Apartment';
      case PropertyType.room:
        return 'Room';
      case PropertyType.house:
        return 'House';
      case PropertyType.studio:
        return 'Studio';
    }
  }
}
