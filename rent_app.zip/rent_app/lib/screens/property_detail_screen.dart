import 'package:flutter/material.dart';
import '../models/property.dart';
import '../services/favorites_service.dart';
import '../theme/app_theme.dart';

class PropertyDetailScreen extends StatefulWidget {
  final Property property;
  const PropertyDetailScreen({super.key, required this.property});

  @override
  State<PropertyDetailScreen> createState() => _PropertyDetailScreenState();
}

class _PropertyDetailScreenState extends State<PropertyDetailScreen> {
  int _currentImage = 0;
  final PageController _pageController = PageController();

  @override
  Widget build(BuildContext context) {
    final p = widget.property;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            backgroundColor: AppTheme.primary,
            actions: [
              ListenableBuilder(
                listenable: FavoritesService.instance,
                builder: (context, _) {
                  final fav = FavoritesService.instance.isFavorite(p.id);
                  return IconButton(
                    icon: Icon(fav ? Icons.favorite : Icons.favorite_border,
                        color: Colors.white),
                    onPressed: () => FavoritesService.instance.toggle(p.id),
                  );
                },
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  PageView.builder(
                    controller: _pageController,
                    itemCount: p.images.length,
                    onPageChanged: (i) => setState(() => _currentImage = i),
                    itemBuilder: (context, index) => Image.network(
                      p.images[index],
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stack) => Container(
                        color: Colors.grey[300],
                        child:
                            const Icon(Icons.home, size: 64, color: Colors.grey),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 12,
                    left: 0,
                    right: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        p.images.length,
                        (i) => Container(
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _currentImage == i
                                ? Colors.white
                                : Colors.white.withOpacity(0.4),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        p.priceLabel,
                        style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primary,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: AppTheme.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(p.typeLabel,
                            style: const TextStyle(
                                color: AppTheme.primary,
                                fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(p.title, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.location_on_outlined,
                          size: 16, color: AppTheme.textLight),
                      const SizedBox(width: 4),
                      Text('${p.address}, ${p.neighborhood}, ${p.city}',
                          style: Theme.of(context).textTheme.bodyMedium),
                    ],
                  ),
                  const Divider(height: 32),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _statColumn(Icons.square_foot, '${p.sizeM2} m²', 'Size'),
                      _statColumn(
                          Icons.bed_outlined, '${p.bedrooms}', 'Bedrooms'),
                      _statColumn(
                          Icons.bathtub_outlined, '${p.bathrooms}', 'Bathrooms'),
                    ],
                  ),
                  const Divider(height: 32),
                  Text('Description',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(p.description,
                      style: const TextStyle(height: 1.5, color: AppTheme.textDark)),
                  const SizedBox(height: 24),
                  Text('Amenities',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: p.amenities
                        .map((a) => Chip(
                              label: Text(a),
                              backgroundColor: AppTheme.background,
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 24),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 24,
                            backgroundColor: AppTheme.primary,
                            child: Text(
                              p.agentName.isNotEmpty ? p.agentName[0] : '?',
                              style: const TextStyle(color: Colors.white),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(p.agentName,
                                    style:
                                        Theme.of(context).textTheme.titleMedium),
                                Text(p.agentPhone,
                                    style: Theme.of(context).textTheme.bodyMedium),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.call, color: AppTheme.primary),
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Calling ${p.agentPhone}...'),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Message sent to agent!')),
                );
              },
              icon: const Icon(Icons.message_outlined),
              label: const Text('Contact agent'),
            ),
          ),
        ),
      ),
    );
  }

  Widget _statColumn(IconData icon, String value, String label) {
    return Column(
      children: [
        Icon(icon, color: AppTheme.primary),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        Text(label, style: const TextStyle(color: AppTheme.textLight, fontSize: 12)),
      ],
    );
  }
}
