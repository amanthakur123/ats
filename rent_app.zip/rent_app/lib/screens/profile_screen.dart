import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const CircleAvatar(
                radius: 32,
                backgroundColor: AppTheme.primary,
                child: Icon(Icons.person, color: Colors.white, size: 32),
              ),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Guest User',
                      style: Theme.of(context).textTheme.titleLarge),
                  const Text('guest@example.com',
                      style: TextStyle(color: AppTheme.textLight)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),
          _menuTile(context, Icons.home_work_outlined, 'My listings'),
          _menuTile(context, Icons.favorite_border, 'Saved searches'),
          _menuTile(context, Icons.notifications_outlined, 'Notifications'),
          _menuTile(context, Icons.settings_outlined, 'Settings'),
          _menuTile(context, Icons.help_outline, 'Help & support'),
          const SizedBox(height: 12),
          _menuTile(context, Icons.logout, 'Log out', color: Colors.red),
        ],
      ),
    );
  }

  Widget _menuTile(BuildContext context, IconData icon, String label,
      {Color? color}) {
    return ListTile(
      leading: Icon(icon, color: color ?? AppTheme.textDark),
      title: Text(label, style: TextStyle(color: color ?? AppTheme.textDark)),
      trailing: const Icon(Icons.chevron_right, color: AppTheme.textLight),
      onTap: () {},
    );
  }
}
