import 'property.dart';

class PropertyFilters {
  String query;
  double minPrice;
  double maxPrice;
  Set<PropertyType> types;
  int minBedrooms;
  bool furnishedOnly;
  bool petsAllowedOnly;

  PropertyFilters({
    this.query = '',
    this.minPrice = 0,
    this.maxPrice = 2000,
    Set<PropertyType>? types,
    this.minBedrooms = 0,
    this.furnishedOnly = false,
    this.petsAllowedOnly = false,
  }) : types = types ?? {};

  PropertyFilters copy() => PropertyFilters(
        query: query,
        minPrice: minPrice,
        maxPrice: maxPrice,
        types: Set.from(types),
        minBedrooms: minBedrooms,
        furnishedOnly: furnishedOnly,
        petsAllowedOnly: petsAllowedOnly,
      );

  bool matches(Property p) {
    if (query.isNotEmpty) {
      final q = query.toLowerCase();
      final haystack =
          '${p.title} ${p.city} ${p.neighborhood} ${p.description}'
              .toLowerCase();
      if (!haystack.contains(q)) return false;
    }
    if (p.price < minPrice || p.price > maxPrice) return false;
    if (types.isNotEmpty && !types.contains(p.type)) return false;
    if (p.bedrooms < minBedrooms) return false;
    if (furnishedOnly && !p.furnished) return false;
    if (petsAllowedOnly && !p.petsAllowed) return false;
    return true;
  }
}
