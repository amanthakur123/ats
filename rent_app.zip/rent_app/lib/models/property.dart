enum PropertyType { apartment, room, house, studio }

class Property {
  final String id;
  final String title;
  final String description;
  final double price; // monthly rent
  final int sizeM2;
  final int bedrooms;
  final int bathrooms;
  final PropertyType type;
  final String city;
  final String neighborhood;
  final String address;
  final double lat;
  final double lng;
  final List<String> images;
  final List<String> amenities;
  final String agentName;
  final String agentPhone;
  final DateTime postedAt;
  final bool furnished;
  final bool petsAllowed;

  const Property({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.sizeM2,
    required this.bedrooms,
    required this.bathrooms,
    required this.type,
    required this.city,
    required this.neighborhood,
    required this.address,
    required this.lat,
    required this.lng,
    required this.images,
    required this.amenities,
    required this.agentName,
    required this.agentPhone,
    required this.postedAt,
    this.furnished = false,
    this.petsAllowed = false,
  });

  String get typeLabel {
    switch (type) {
      case PropertyType.apartment:
        return 'Apartment';
      case PropertyType.room:
        return 'Room';
      case PropertyType.house:
        return 'House';
      case PropertyType.studio:
        return 'Studio';
    }
  }

  String get priceLabel => '€${price.toStringAsFixed(0)}/mo';
}
