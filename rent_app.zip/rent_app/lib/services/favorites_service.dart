import 'package:flutter/foundation.dart';

/// Simple global favorites store. No external state-management package
/// required — just a ChangeNotifier singleton listened to via
/// AnimatedBuilder/ListenableBuilder in the UI.
class FavoritesService extends ChangeNotifier {
  FavoritesService._internal();
  static final FavoritesService instance = FavoritesService._internal();

  final Set<String> _favoriteIds = {};

  bool isFavorite(String propertyId) => _favoriteIds.contains(propertyId);

  void toggle(String propertyId) {
    if (_favoriteIds.contains(propertyId)) {
      _favoriteIds.remove(propertyId);
    } else {
      _favoriteIds.add(propertyId);
    }
    notifyListeners();
  }

  Set<String> get favoriteIds => _favoriteIds;
}
